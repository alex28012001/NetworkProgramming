﻿namespace wcfConfig
{
    internal class Calc
    {
    }
}