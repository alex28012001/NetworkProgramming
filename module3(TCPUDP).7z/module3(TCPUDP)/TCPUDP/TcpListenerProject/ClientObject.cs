﻿using System;
using System.Net.Sockets;
using System.Text;

namespace TcpListenerProject
{
    public class ClientObject
    {
        //private static int _port = 8888;
        //private static string _address = "127.0.0.1";

        public TcpClient client;
        private NetworkStream stream;

        public ClientObject(TcpClient tcpClient)
        {
            client = tcpClient;
        }

        public void Process()
        {
            stream = null;
            try
            {
                stream = client.GetStream();
                byte[] data = new byte[64]; // буфер для получаемых данных
                while (true)
                {
                    // получаем сообщение
                    var builder = new StringBuilder();
                    int bytes = 0;
                    do
                    {
                        bytes = stream.Read(data, 0, data.Length);
                        builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                    }
                    while (stream.DataAvailable);

                    string message = builder.ToString();

                    string[] temp = message.Split(';');

                    int rezult = 0;
                    switch(temp[0])
                    {
                        case "Sum": rezult = Sum(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2]));break;
                                
                        case "Sub": rezult = Sub(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2]));break;

                        case "Desc": rezult = Desc(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;

                        case "Multy": rezult = Multy(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;
                    }


                    Console.WriteLine(message);
                    // отправляем обратно сообщение в верхнем регистре
                    message = rezult.ToString();
                    data = Encoding.Unicode.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                stream?.Close();
                client?.Close();
            }
        }


        private int Sum(int a,int b)
        {
            return a + b;
        }

        private int Sub(int a,int b)
        {
            return a - b;
        }

        private int Desc(int a, int b)
        {
            return a / b;
        }

        private int Multy(int a, int b)
        {
            return a * b;
        }
    }
}
