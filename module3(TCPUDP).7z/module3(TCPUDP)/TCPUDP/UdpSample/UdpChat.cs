﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UdpSample
{
    public class UdpChat
    {
        private readonly int _localPort;
        public UdpChat(int localPort)
        {
            _localPort = localPort;
        }

        public void Send(string datagram, long remoteIPAddress, int remotePort)
        {
            // Создаем UdpClient
            UdpClient sender = new UdpClient();

            // Создаем endPoint по информации об удаленном хосте
            IPEndPoint endPoint = new IPEndPoint(remoteIPAddress, remotePort);

            try
            {
                
                string []temp = datagram.Split(' ');
                int a;
                int.TryParse(temp[0], out a);
                int b;
                int.TryParse(temp[2], out b);

                string rezult = null; 
                switch(temp[1])
                {
                    case "+" : rezult = $"Sum;{a};{b}";break;
                    case "-": rezult = $"Sub;{a};{b}"; break;
                    case "/": rezult = $"Desc;{a};{b}"; break;
                    case "*": rezult = $"Multy;{a};{b}"; break;
                }

                


                // Преобразуем данные в массив байтов
                byte[] bytes = Encoding.UTF8.GetBytes(rezult);

                // Отправляем данные
                sender.Send(bytes, bytes.Length, endPoint);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Возникло исключение: " + ex.ToString() + "\n  " + ex.Message);
            }
            finally
            {
                // Закрыть соединение
                sender.Close();
            }
        }

        public void Receiver()
        {
            // Создаем UdpClient для чтения входящих данных
            UdpClient receivingUdpClient = new UdpClient(_localPort);

            IPEndPoint RemoteIpEndPoint = null;

            try
            {
                Console.WriteLine(
                   "\n-----------*******Общий чат*******-----------");

                while (true)
                {
                    // Ожидание дейтаграммы
                    byte[] receiveBytes = receivingUdpClient.Receive(
                       ref RemoteIpEndPoint);

                    // Преобразуем и отображаем данные
                    string returnData = Encoding.UTF8.GetString(receiveBytes);


                    string[] temp = returnData.Split(';');

                    int rezult = 0;
                    switch (temp[0])
                    {
                        case "Sum": rezult = Sum(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;

                        case "Sub": rezult = Sub(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;

                        case "Desc": rezult = Desc(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;

                        case "Multy": rezult = Multy(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2])); break;
                    }


                    Console.WriteLine(" --> " + rezult.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Возникло исключение: " + ex.ToString() + "\n  " + ex.Message);
            }
        }

        private int Sum(int a, int b)
        {
            return a + b;
        }

        private int Sub(int a, int b)
        {
            return a - b;
        }

        private int Desc(int a, int b)
        {
            return a / b;
        }

        private int Multy(int a, int b)
        {
            return a * b;
        }
    }
}
